//
//  ViewController.m
//  iOS2048Arithmetic
//
//  Created by Earth on 2020/9/29.
//

#import <WebKit/WebKit.h>
#import <Masonry/Masonry.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import "ViewController.h"
#import "ViewController+Color.h"

#define GOOGLE_GAD_DEBUG  0

@interface ViewController () <WKUIDelegate, WKNavigationDelegate, GADInterstitialDelegate, GADBannerViewDelegate>
@property(nonatomic, strong) WKWebView *wkWebView;
@property(nonatomic, strong) WKWebViewConfiguration *wkWebViewConfig;
@property(nonatomic, strong) NSTimer *timer;
@property(nonatomic, assign) NSInteger timeCount;
@property(nonatomic, assign) NSInteger timeToalSecond;
@property(nonatomic, assign) BOOL isIdentifierFirstLoad;
@property(nonatomic, strong) GADInterstitial *interstitial;
@property(nonatomic, strong) GADBannerView *bannerView;
@end

@implementation ViewController

- (instancetype)initWithCoder:(NSCoder *)coder
{
    self = [super initWithCoder:coder];
    if (self) {
        _timeToalSecond = 1800;
        _isIdentifierFirstLoad = YES;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self.view setBackgroundColor:[self backgroundColor:@"#FAF8EF"]];
    
    [self viewDidLoadRequestWebHtml];
    
    [self startNewGADInterstitial];
    
    [self startNewGADBannerView];
}

- (void)viewDidLoadRequestWebHtml
{
    NSString *urlString = @"webhtml/index.html";
    NSURL *baseURL = [NSURL URLWithString:urlString relativeToURL:[[NSBundle mainBundle] bundleURL]];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:baseURL];
    [self.wkWebView loadRequest:request];
}


#pragma mark - GADBannerView

- (void)startNewGADBannerView
{
    self.bannerView = [[GADBannerView alloc] initWithAdSize:kGADAdSizeLargeBanner];
    
#if GOOGLE_GAD_DEBUG
    self.bannerView.adUnitID = @"ca-app-pub-3940256099942544/2934735716";
#else
    self.bannerView.adUnitID = @"ca-app-pub-3574624433847272/3637503316";
#endif
    self.bannerView.delegate = self;
    self.bannerView.rootViewController = self;
    [self.bannerView loadRequest:[GADRequest request]];
}

- (void)addBannerViewToView:(UIView *)bannerView
{
    bannerView.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:bannerView];
    [bannerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.view.mas_centerX);
        make.bottom.equalTo(self.view.mas_safeAreaLayoutGuideBottom).offset(-20);
    }];
}

- (void)adViewDidReceiveAd:(GADBannerView *)adView {
    [self addBannerViewToView:self.bannerView];
    adView.alpha = 0;
    [UIView animateWithDuration:1.0 animations:^{
        adView.alpha = 1;
    }];
}


#pragma mark - GADInterstitial

- (void)startNewGADInterstitial
{
    if (self.timer) {
        [self.timer invalidate];
        self.timer = nil;
    }
    [self createNewInterstitial];
    self.timeCount = self.timeToalSecond;
    self.timer = [NSTimer scheduledTimerWithTimeInterval:1.0f
                                                  target:self
                                                selector:@selector(decrementTimeLeft:)
                                                userInfo:nil
                                                 repeats:YES];
}

- (void)createNewInterstitial
{
#if GOOGLE_GAD_DEBUG
    self.interstitial = [[GADInterstitial alloc] initWithAdUnitID:@"ca-app-pub-3940256099942544/4411468910"];
    [self.interstitial setDelegate:self];
    [self.interstitial loadRequest:[GADRequest request]];
#else
    NSMutableArray *identifiers = @[
        @"ca-app-pub-3574624433847272/8674261472",
        @"ca-app-pub-3574624433847272/1782669621",
        @"ca-app-pub-3574624433847272/1591097932"
    ].mutableCopy;
    if ([identifiers count] > 1) {
        for (NSUInteger i = [identifiers count] - 1; i > 0; --i) {
            [identifiers exchangeObjectAtIndex:i withObjectAtIndex:arc4random_uniform((int32_t)(i + 1))];
        }
    }
    NSString *identifier = [identifiers firstObject];
    if (identifier.length > 0) {
        self.interstitial = [[GADInterstitial alloc] initWithAdUnitID:identifier];
        [self.interstitial setDelegate:self];
        [self.interstitial loadRequest:[GADRequest request]];
    }
#endif
}

- (void)presentGADMobileGoogleAds
{
    [self.timer invalidate];
    self.timer = nil;
    if (self.interstitial.isReady) {
        [self.interstitial presentFromRootViewController:self];
    } else {
        [self startNewGADInterstitial];
    }
}

- (void)decrementTimeLeft:(NSTimer *)timer
{
    self.timeCount --;
    if (self.timeCount <= 0) {
        [self presentGADMobileGoogleAds];
    }
}

- (void)interstitialDidReceiveAd:(GADInterstitial *)ad {
    if (self.isIdentifierFirstLoad) {
        self.isIdentifierFirstLoad = NO;
        self.timeCount = 0;
    }
}

- (void)interstitialDidDismissScreen:(GADInterstitial *)interstitial {
    [self startNewGADInterstitial];
}


#pragma mark - Private

- (WKWebView *)wkWebView
{
    if (!_wkWebView) {
        _wkWebView = [[WKWebView alloc] initWithFrame:self.view.bounds configuration:self.wkWebViewConfig];
        _wkWebView.navigationDelegate = self;
        _wkWebView.UIDelegate = self;
        _wkWebView.allowsBackForwardNavigationGestures = NO;
        _wkWebView.scrollView.showsHorizontalScrollIndicator = NO;
        _wkWebView.scrollView.bounces = YES;
        [_wkWebView.scrollView setBackgroundColor:[self backgroundColor:@"#FAF8EF"]];
        [self.view addSubview:_wkWebView];
    }
    return _wkWebView;
}

- (WKWebViewConfiguration *)wkWebViewConfig
{
    if (!_wkWebViewConfig) {
        _wkWebViewConfig = [[WKWebViewConfiguration alloc] init];
    }
    return _wkWebViewConfig;
}

@end
